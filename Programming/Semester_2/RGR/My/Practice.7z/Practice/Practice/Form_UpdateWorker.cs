﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practice
{
    public partial class Form_UpdateWorker : Form
    {
        public Form_Worker MainForm { get; set; }
        public static string connection = "Provider=Microsoft.ACE.OLEDB.16.0;Data Source=DatabaseP.accdb";
        private OleDbConnection dbConnection;
        public Form_UpdateWorker()
        {
            InitializeComponent();
            dbConnection = new OleDbConnection(connection);
            dbConnection.Open();
        }

        private void update_button_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(id_textBox.Text);
                string w_name = w_name_textBox.Text;
                DateTime birth_date = DateTime.Parse(birth_date_textBox.Text);
                string phone_number = phone_number_textBox.Text;
                DateTime hire_date = DateTime.Parse(hire_date_textBox.Text);
                int salary = Convert.ToInt32(salary_textBox.Text);

                string query = "UPDATE worker " +
                    "SET w_name = @w_name, birth_date = @birth_date, phone_number = @phone_number, hire_date = @hire_date, salary = @salary " +
                    "WHERE [id] = @id";
                OleDbCommand command = new OleDbCommand(query, dbConnection);

                command.Parameters.AddWithValue("@w_name", w_name);
                command.Parameters.AddWithValue("@birth_date", birth_date);
                command.Parameters.AddWithValue("@phone_number", phone_number);
                command.Parameters.AddWithValue("@hire_date", hire_date);
                command.Parameters.AddWithValue("@salary", salary);
                command.Parameters.AddWithValue("@id", id);

                command.ExecuteNonQuery();

                MessageBox.Show("Worker updated!");

                MainForm.UpdateDataGridView();

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
