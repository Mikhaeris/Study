﻿namespace Practice
{
    partial class Form_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.warehouse_button = new System.Windows.Forms.Button();
            this.worker_button = new System.Windows.Forms.Button();
            this.exit_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // warehouse_button
            // 
            this.warehouse_button.Location = new System.Drawing.Point(525, 73);
            this.warehouse_button.Name = "warehouse_button";
            this.warehouse_button.Size = new System.Drawing.Size(202, 69);
            this.warehouse_button.TabIndex = 0;
            this.warehouse_button.Text = "База складов";
            this.warehouse_button.UseVisualStyleBackColor = true;
            this.warehouse_button.Click += new System.EventHandler(this.warehouse_button_Click);
            // 
            // worker_button
            // 
            this.worker_button.Location = new System.Drawing.Point(525, 169);
            this.worker_button.Name = "worker_button";
            this.worker_button.Size = new System.Drawing.Size(202, 69);
            this.worker_button.TabIndex = 1;
            this.worker_button.Text = "База сотрудников";
            this.worker_button.UseVisualStyleBackColor = true;
            this.worker_button.Click += new System.EventHandler(this.worker_button_Click);
            // 
            // exit_button
            // 
            this.exit_button.Location = new System.Drawing.Point(525, 264);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(202, 69);
            this.exit_button.TabIndex = 2;
            this.exit_button.Text = "Выйти";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // Form_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.worker_button);
            this.Controls.Add(this.warehouse_button);
            this.Name = "Form_Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Информационная система предприятия";
            this.Load += new System.EventHandler(this.Form_Menu_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button warehouse_button;
        private System.Windows.Forms.Button worker_button;
        private System.Windows.Forms.Button exit_button;
    }
}

