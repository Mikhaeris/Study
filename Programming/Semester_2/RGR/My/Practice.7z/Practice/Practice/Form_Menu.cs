﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practice
{
    public partial class Form_Menu : Form
    {
        public Form_Menu()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void warehouse_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form_Warehouse f_w = new Form_Warehouse();
            f_w.Owner = this;
            f_w.StartPosition = FormStartPosition.Manual;
            f_w.Location = this.Location;
            f_w.Show();
        }
        
        private void worker_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form_Worker f_w = new Form_Worker();
            f_w.Owner = this;
            f_w.StartPosition = FormStartPosition.Manual;
            f_w.Location = this.Location;
            f_w.Show();
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form_Menu_Load(object sender, EventArgs e)
        {

        }
    }
}