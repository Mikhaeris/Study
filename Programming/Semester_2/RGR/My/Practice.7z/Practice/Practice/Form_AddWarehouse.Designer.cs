﻿namespace Practice
{
    partial class Form_AddWarehouse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.add_button = new System.Windows.Forms.Button();
            this.exit_button = new System.Windows.Forms.Button();
            this.id_textBox = new System.Windows.Forms.TextBox();
            this.product_type_textBox = new System.Windows.Forms.TextBox();
            this.address_textBox = new System.Windows.Forms.TextBox();
            this.places_count_textBox = new System.Windows.Forms.TextBox();
            this.worker_id_textBox = new System.Windows.Forms.TextBox();
            this.id_label = new System.Windows.Forms.Label();
            this.product_type_label = new System.Windows.Forms.Label();
            this.address_label = new System.Windows.Forms.Label();
            this.places_count_label = new System.Windows.Forms.Label();
            this.worker_id_label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // add_button
            // 
            this.add_button.Location = new System.Drawing.Point(12, 84);
            this.add_button.Name = "add_button";
            this.add_button.Size = new System.Drawing.Size(304, 61);
            this.add_button.TabIndex = 0;
            this.add_button.Text = "add";
            this.add_button.UseVisualStyleBackColor = true;
            this.add_button.Click += new System.EventHandler(this.add_button_Click);
            // 
            // exit_button
            // 
            this.exit_button.Location = new System.Drawing.Point(350, 84);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(283, 61);
            this.exit_button.TabIndex = 1;
            this.exit_button.Text = "exit";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // id_textBox
            // 
            this.id_textBox.Location = new System.Drawing.Point(12, 42);
            this.id_textBox.Name = "id_textBox";
            this.id_textBox.Size = new System.Drawing.Size(100, 20);
            this.id_textBox.TabIndex = 2;
            // 
            // product_type_textBox
            // 
            this.product_type_textBox.Location = new System.Drawing.Point(140, 42);
            this.product_type_textBox.Name = "product_type_textBox";
            this.product_type_textBox.Size = new System.Drawing.Size(100, 20);
            this.product_type_textBox.TabIndex = 3;
            // 
            // address_textBox
            // 
            this.address_textBox.Location = new System.Drawing.Point(267, 41);
            this.address_textBox.Name = "address_textBox";
            this.address_textBox.Size = new System.Drawing.Size(100, 20);
            this.address_textBox.TabIndex = 4;
            // 
            // places_count_textBox
            // 
            this.places_count_textBox.Location = new System.Drawing.Point(391, 42);
            this.places_count_textBox.Name = "places_count_textBox";
            this.places_count_textBox.Size = new System.Drawing.Size(100, 20);
            this.places_count_textBox.TabIndex = 5;
            // 
            // worker_id_textBox
            // 
            this.worker_id_textBox.Location = new System.Drawing.Point(510, 42);
            this.worker_id_textBox.Name = "worker_id_textBox";
            this.worker_id_textBox.Size = new System.Drawing.Size(100, 20);
            this.worker_id_textBox.TabIndex = 6;
            // 
            // id_label
            // 
            this.id_label.AutoSize = true;
            this.id_label.Location = new System.Drawing.Point(13, 14);
            this.id_label.Name = "id_label";
            this.id_label.Size = new System.Drawing.Size(15, 13);
            this.id_label.TabIndex = 7;
            this.id_label.Text = "id";
            // 
            // product_type_label
            // 
            this.product_type_label.AutoSize = true;
            this.product_type_label.Location = new System.Drawing.Point(137, 10);
            this.product_type_label.Name = "product_type_label";
            this.product_type_label.Size = new System.Drawing.Size(69, 13);
            this.product_type_label.TabIndex = 8;
            this.product_type_label.Text = "product_type";
            // 
            // address_label
            // 
            this.address_label.AutoSize = true;
            this.address_label.Location = new System.Drawing.Point(272, 14);
            this.address_label.Name = "address_label";
            this.address_label.Size = new System.Drawing.Size(44, 13);
            this.address_label.TabIndex = 9;
            this.address_label.Text = "address";
            // 
            // places_count_label
            // 
            this.places_count_label.AutoSize = true;
            this.places_count_label.Location = new System.Drawing.Point(388, 14);
            this.places_count_label.Name = "places_count_label";
            this.places_count_label.Size = new System.Drawing.Size(71, 13);
            this.places_count_label.TabIndex = 10;
            this.places_count_label.Text = "places_count";
            // 
            // worker_id_label
            // 
            this.worker_id_label.AutoSize = true;
            this.worker_id_label.Location = new System.Drawing.Point(507, 14);
            this.worker_id_label.Name = "worker_id_label";
            this.worker_id_label.Size = new System.Drawing.Size(53, 13);
            this.worker_id_label.TabIndex = 11;
            this.worker_id_label.Text = "worker_id";
            // 
            // Form_AddWarehouse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 157);
            this.Controls.Add(this.worker_id_label);
            this.Controls.Add(this.places_count_label);
            this.Controls.Add(this.address_label);
            this.Controls.Add(this.product_type_label);
            this.Controls.Add(this.id_label);
            this.Controls.Add(this.worker_id_textBox);
            this.Controls.Add(this.places_count_textBox);
            this.Controls.Add(this.address_textBox);
            this.Controls.Add(this.product_type_textBox);
            this.Controls.Add(this.id_textBox);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.add_button);
            this.Name = "Form_AddWarehouse";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Form_AddWarehouse";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button add_button;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.TextBox id_textBox;
        private System.Windows.Forms.TextBox product_type_textBox;
        private System.Windows.Forms.TextBox address_textBox;
        private System.Windows.Forms.TextBox places_count_textBox;
        private System.Windows.Forms.TextBox worker_id_textBox;
        private System.Windows.Forms.Label id_label;
        private System.Windows.Forms.Label product_type_label;
        private System.Windows.Forms.Label address_label;
        private System.Windows.Forms.Label places_count_label;
        private System.Windows.Forms.Label worker_id_label;
    }
}