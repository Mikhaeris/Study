﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practice
{
    public partial class Form_UpdateWarehouse : Form
    {
        public Form_Warehouse MainForm { get; set; }
        public static string connection = "Provider=Microsoft.ACE.OLEDB.16.0;Data Source=DatabaseP.accdb";
        private OleDbConnection dbConnection;
        public Form_UpdateWarehouse()
        {
            InitializeComponent();
            dbConnection = new OleDbConnection(connection);
            dbConnection.Open();
        }

        private void update_button_Click(object sender, EventArgs e)
        {
            try
            {
                int id              = Convert.ToInt32(id_textBox.Text);
                string product_type = product_type_textBox.Text;
                string address      = address_textBox.Text;
                int places_count    = Convert.ToInt32(places_count_textBox.Text);
                int worker_id       = Convert.ToInt32(worker_id_textBox.Text);

                string query = "UPDATE warehouse SET product_type = @product_type, address = @address, places_count = @places_count, worker_id = @worker_id WHERE [id] = @id";
                OleDbCommand command = new OleDbCommand(query, dbConnection);

                command.Parameters.AddWithValue("@product_type", product_type);
                command.Parameters.AddWithValue("@address", address);
                command.Parameters.AddWithValue("@places_count", places_count);
                command.Parameters.AddWithValue("@worker_id", worker_id);
                command.Parameters.AddWithValue("@id", id);

                command.ExecuteNonQuery();

                MessageBox.Show("Warehouse updated!");

                MainForm.UpdateDataGridView();

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
