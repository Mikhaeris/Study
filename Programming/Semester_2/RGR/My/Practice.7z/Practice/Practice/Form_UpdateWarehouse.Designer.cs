﻿namespace Practice
{
    partial class Form_UpdateWarehouse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.worker_id_label = new System.Windows.Forms.Label();
            this.places_count_label = new System.Windows.Forms.Label();
            this.address_label = new System.Windows.Forms.Label();
            this.product_type_label = new System.Windows.Forms.Label();
            this.id_label = new System.Windows.Forms.Label();
            this.worker_id_textBox = new System.Windows.Forms.TextBox();
            this.places_count_textBox = new System.Windows.Forms.TextBox();
            this.address_textBox = new System.Windows.Forms.TextBox();
            this.product_type_textBox = new System.Windows.Forms.TextBox();
            this.id_textBox = new System.Windows.Forms.TextBox();
            this.exit_button = new System.Windows.Forms.Button();
            this.update_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // worker_id_label
            // 
            this.worker_id_label.AutoSize = true;
            this.worker_id_label.Location = new System.Drawing.Point(507, 23);
            this.worker_id_label.Name = "worker_id_label";
            this.worker_id_label.Size = new System.Drawing.Size(53, 13);
            this.worker_id_label.TabIndex = 23;
            this.worker_id_label.Text = "worker_id";
            // 
            // places_count_label
            // 
            this.places_count_label.AutoSize = true;
            this.places_count_label.Location = new System.Drawing.Point(388, 23);
            this.places_count_label.Name = "places_count_label";
            this.places_count_label.Size = new System.Drawing.Size(71, 13);
            this.places_count_label.TabIndex = 22;
            this.places_count_label.Text = "places_count";
            // 
            // address_label
            // 
            this.address_label.AutoSize = true;
            this.address_label.Location = new System.Drawing.Point(272, 15);
            this.address_label.Name = "address_label";
            this.address_label.Size = new System.Drawing.Size(44, 13);
            this.address_label.TabIndex = 21;
            this.address_label.Text = "address";
            // 
            // product_type_label
            // 
            this.product_type_label.AutoSize = true;
            this.product_type_label.Location = new System.Drawing.Point(137, 11);
            this.product_type_label.Name = "product_type_label";
            this.product_type_label.Size = new System.Drawing.Size(69, 13);
            this.product_type_label.TabIndex = 20;
            this.product_type_label.Text = "product_type";
            // 
            // id_label
            // 
            this.id_label.AutoSize = true;
            this.id_label.Location = new System.Drawing.Point(13, 15);
            this.id_label.Name = "id_label";
            this.id_label.Size = new System.Drawing.Size(15, 13);
            this.id_label.TabIndex = 19;
            this.id_label.Text = "id";
            // 
            // worker_id_textBox
            // 
            this.worker_id_textBox.Location = new System.Drawing.Point(510, 43);
            this.worker_id_textBox.Name = "worker_id_textBox";
            this.worker_id_textBox.Size = new System.Drawing.Size(100, 20);
            this.worker_id_textBox.TabIndex = 18;
            // 
            // places_count_textBox
            // 
            this.places_count_textBox.Location = new System.Drawing.Point(391, 43);
            this.places_count_textBox.Name = "places_count_textBox";
            this.places_count_textBox.Size = new System.Drawing.Size(100, 20);
            this.places_count_textBox.TabIndex = 17;
            // 
            // address_textBox
            // 
            this.address_textBox.Location = new System.Drawing.Point(267, 42);
            this.address_textBox.Name = "address_textBox";
            this.address_textBox.Size = new System.Drawing.Size(100, 20);
            this.address_textBox.TabIndex = 16;
            // 
            // product_type_textBox
            // 
            this.product_type_textBox.Location = new System.Drawing.Point(140, 43);
            this.product_type_textBox.Name = "product_type_textBox";
            this.product_type_textBox.Size = new System.Drawing.Size(100, 20);
            this.product_type_textBox.TabIndex = 15;
            // 
            // id_textBox
            // 
            this.id_textBox.Location = new System.Drawing.Point(12, 43);
            this.id_textBox.Name = "id_textBox";
            this.id_textBox.Size = new System.Drawing.Size(100, 20);
            this.id_textBox.TabIndex = 14;
            // 
            // exit_button
            // 
            this.exit_button.Location = new System.Drawing.Point(350, 85);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(283, 61);
            this.exit_button.TabIndex = 13;
            this.exit_button.Text = "exit";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // update_button
            // 
            this.update_button.Location = new System.Drawing.Point(12, 85);
            this.update_button.Name = "update_button";
            this.update_button.Size = new System.Drawing.Size(304, 61);
            this.update_button.TabIndex = 12;
            this.update_button.Text = "update";
            this.update_button.UseVisualStyleBackColor = true;
            this.update_button.Click += new System.EventHandler(this.update_button_Click);
            // 
            // Form_UpdateWarehouse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(647, 170);
            this.Controls.Add(this.worker_id_label);
            this.Controls.Add(this.places_count_label);
            this.Controls.Add(this.address_label);
            this.Controls.Add(this.product_type_label);
            this.Controls.Add(this.id_label);
            this.Controls.Add(this.worker_id_textBox);
            this.Controls.Add(this.places_count_textBox);
            this.Controls.Add(this.address_textBox);
            this.Controls.Add(this.product_type_textBox);
            this.Controls.Add(this.id_textBox);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.update_button);
            this.Name = "Form_UpdateWarehouse";
            this.Text = "Form_UpdateWarehouse";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label worker_id_label;
        private System.Windows.Forms.Label places_count_label;
        private System.Windows.Forms.Label address_label;
        private System.Windows.Forms.Label product_type_label;
        private System.Windows.Forms.Label id_label;
        private System.Windows.Forms.TextBox worker_id_textBox;
        private System.Windows.Forms.TextBox places_count_textBox;
        private System.Windows.Forms.TextBox address_textBox;
        private System.Windows.Forms.TextBox product_type_textBox;
        private System.Windows.Forms.TextBox id_textBox;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.Button update_button;
    }
}