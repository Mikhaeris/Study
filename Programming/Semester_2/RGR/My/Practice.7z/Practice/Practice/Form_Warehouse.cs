﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practice
{
    public partial class Form_Warehouse : Form
    {
        public static string connection = "Provider=Microsoft.ACE.OLEDB.16.0;Data Source=DatabaseP.accdb";
        public OleDbConnection dbConnection;
        public Form_Warehouse()
        {
            InitializeComponent();
            dbConnection = new OleDbConnection(connection);
            dbConnection.Open();
        }

        private void Form_Warehouse_Load(object sender, EventArgs e)
        {
            this.warehouseTableAdapter.Fill(this.databasePDataSet1.warehouse);
        }

        private void Form_Warehouse_FormClosing(object sender, FormClosingEventArgs e)
        {
            dbConnection.Close();
        }

        public void UpdateDataGridView()
        {
            this.warehouseTableAdapter.Fill(this.databasePDataSet1.warehouse);
        }

        private void SaveChanges()
        {
            this.dataGridView1.EndEdit();
            this.warehouseBindingSource.EndEdit();
            this.warehouseTableAdapter.Update(this.databasePDataSet1.warehouse);
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            SaveChanges();
            if (this.Owner != null)
                this.Owner.Show();
            this.Close();

        }

        private void add_warehouse_button_Click(object sender, EventArgs e)
        {
            Form_AddWarehouse faw = new Form_AddWarehouse();
            faw.Owner             = this;
            faw.MainForm          = this;
            faw.StartPosition     = FormStartPosition.Manual;
            faw.Location          = this.Location;
            faw.Show();
        }

        private void update_warehouse_button_Click(object sender, EventArgs e)
        {
            Form_UpdateWarehouse faw = new Form_UpdateWarehouse();
            faw.Owner                = this;
            faw.MainForm             = this;
            faw.StartPosition        = FormStartPosition.Manual;
            faw.Location             = this.Location;
            faw.Show();
        }

        private void delete_warehouse_button_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(delete_warehouse_textBox.Text);

                string query = "DELETE FROM warehouse WHERE [id] = @id";
                OleDbCommand command = new OleDbCommand(query, dbConnection);
                command.Parameters.AddWithValue("@id", id);
                command.ExecuteNonQuery();

                MessageBox.Show("Warehouse deleted successfully.");

                this.warehouseTableAdapter.Fill(this.databasePDataSet1.warehouse);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void find_button_Click(object sender, EventArgs e)
        {
            try
            {
                int worker_id = Convert.ToInt32(find_textBox.Text);
                string query = "SELECT * FROM warehouse WHERE worker_id = @worker_id";
                OleDbCommand command = new OleDbCommand(query, dbConnection);
                command.Parameters.AddWithValue("@worker_id", worker_id);

                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(command);
                DataTable dt = new DataTable();
                dataAdapter.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void reset_button_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = databasePDataSet1.warehouse;
        }

        private void by_ascending_button_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM warehouse ORDER BY 4 ASC";
            OleDbDataAdapter command = new OleDbDataAdapter(query, dbConnection);
            DataTable dt = new DataTable();
            command.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void by_descending_button_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM warehouse ORDER BY 4 DESC";
            OleDbDataAdapter command = new OleDbDataAdapter(query, dbConnection);
            DataTable dt = new DataTable();
            command.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
