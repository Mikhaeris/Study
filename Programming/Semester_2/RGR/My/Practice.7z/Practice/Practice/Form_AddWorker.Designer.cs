﻿namespace Practice
{
    partial class Form_AddWorker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hire_date_label = new System.Windows.Forms.Label();
            this.phone_number_label = new System.Windows.Forms.Label();
            this.birth_date_label = new System.Windows.Forms.Label();
            this.w_name_label = new System.Windows.Forms.Label();
            this.id_label = new System.Windows.Forms.Label();
            this.hire_date_textBox = new System.Windows.Forms.TextBox();
            this.phone_number_textBox = new System.Windows.Forms.TextBox();
            this.birth_date_textBox = new System.Windows.Forms.TextBox();
            this.w_name_textBox = new System.Windows.Forms.TextBox();
            this.id_textBox = new System.Windows.Forms.TextBox();
            this.exit_button = new System.Windows.Forms.Button();
            this.add_button = new System.Windows.Forms.Button();
            this.salary_label = new System.Windows.Forms.Label();
            this.salary_textBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // hire_date_label
            // 
            this.hire_date_label.AutoSize = true;
            this.hire_date_label.Location = new System.Drawing.Point(512, 18);
            this.hire_date_label.Name = "hire_date_label";
            this.hire_date_label.Size = new System.Drawing.Size(51, 13);
            this.hire_date_label.TabIndex = 23;
            this.hire_date_label.Text = "hire_date";
            // 
            // phone_number_label
            // 
            this.phone_number_label.AutoSize = true;
            this.phone_number_label.Location = new System.Drawing.Point(393, 18);
            this.phone_number_label.Name = "phone_number_label";
            this.phone_number_label.Size = new System.Drawing.Size(78, 13);
            this.phone_number_label.TabIndex = 22;
            this.phone_number_label.Text = "phone_number";
            // 
            // birth_date_label
            // 
            this.birth_date_label.AutoSize = true;
            this.birth_date_label.Location = new System.Drawing.Point(277, 18);
            this.birth_date_label.Name = "birth_date_label";
            this.birth_date_label.Size = new System.Drawing.Size(54, 13);
            this.birth_date_label.TabIndex = 21;
            this.birth_date_label.Text = "birth_date";
            // 
            // w_name_label
            // 
            this.w_name_label.AutoSize = true;
            this.w_name_label.Location = new System.Drawing.Point(142, 14);
            this.w_name_label.Name = "w_name_label";
            this.w_name_label.Size = new System.Drawing.Size(47, 13);
            this.w_name_label.TabIndex = 20;
            this.w_name_label.Text = "w_name";
            // 
            // id_label
            // 
            this.id_label.AutoSize = true;
            this.id_label.Location = new System.Drawing.Point(18, 18);
            this.id_label.Name = "id_label";
            this.id_label.Size = new System.Drawing.Size(15, 13);
            this.id_label.TabIndex = 19;
            this.id_label.Text = "id";
            // 
            // hire_date_textBox
            // 
            this.hire_date_textBox.Location = new System.Drawing.Point(515, 46);
            this.hire_date_textBox.Name = "hire_date_textBox";
            this.hire_date_textBox.Size = new System.Drawing.Size(100, 20);
            this.hire_date_textBox.TabIndex = 18;
            // 
            // phone_number_textBox
            // 
            this.phone_number_textBox.Location = new System.Drawing.Point(396, 46);
            this.phone_number_textBox.Name = "phone_number_textBox";
            this.phone_number_textBox.Size = new System.Drawing.Size(100, 20);
            this.phone_number_textBox.TabIndex = 17;
            // 
            // birth_date_textBox
            // 
            this.birth_date_textBox.Location = new System.Drawing.Point(272, 45);
            this.birth_date_textBox.Name = "birth_date_textBox";
            this.birth_date_textBox.Size = new System.Drawing.Size(100, 20);
            this.birth_date_textBox.TabIndex = 16;
            // 
            // w_name_textBox
            // 
            this.w_name_textBox.Location = new System.Drawing.Point(145, 46);
            this.w_name_textBox.Name = "w_name_textBox";
            this.w_name_textBox.Size = new System.Drawing.Size(100, 20);
            this.w_name_textBox.TabIndex = 15;
            // 
            // id_textBox
            // 
            this.id_textBox.Location = new System.Drawing.Point(17, 46);
            this.id_textBox.Name = "id_textBox";
            this.id_textBox.Size = new System.Drawing.Size(100, 20);
            this.id_textBox.TabIndex = 14;
            // 
            // exit_button
            // 
            this.exit_button.Location = new System.Drawing.Point(355, 88);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(283, 61);
            this.exit_button.TabIndex = 13;
            this.exit_button.Text = "exit";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // add_button
            // 
            this.add_button.Location = new System.Drawing.Point(17, 88);
            this.add_button.Name = "add_button";
            this.add_button.Size = new System.Drawing.Size(304, 61);
            this.add_button.TabIndex = 12;
            this.add_button.Text = "add";
            this.add_button.UseVisualStyleBackColor = true;
            this.add_button.Click += new System.EventHandler(this.add_button_Click);
            // 
            // salary_label
            // 
            this.salary_label.AutoSize = true;
            this.salary_label.Location = new System.Drawing.Point(638, 18);
            this.salary_label.Name = "salary_label";
            this.salary_label.Size = new System.Drawing.Size(34, 13);
            this.salary_label.TabIndex = 25;
            this.salary_label.Text = "salary";
            // 
            // salary_textBox
            // 
            this.salary_textBox.Location = new System.Drawing.Point(641, 46);
            this.salary_textBox.Name = "salary_textBox";
            this.salary_textBox.Size = new System.Drawing.Size(100, 20);
            this.salary_textBox.TabIndex = 24;
            // 
            // Form_AddWorker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 168);
            this.Controls.Add(this.salary_label);
            this.Controls.Add(this.salary_textBox);
            this.Controls.Add(this.hire_date_label);
            this.Controls.Add(this.phone_number_label);
            this.Controls.Add(this.birth_date_label);
            this.Controls.Add(this.w_name_label);
            this.Controls.Add(this.id_label);
            this.Controls.Add(this.hire_date_textBox);
            this.Controls.Add(this.phone_number_textBox);
            this.Controls.Add(this.birth_date_textBox);
            this.Controls.Add(this.w_name_textBox);
            this.Controls.Add(this.id_textBox);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.add_button);
            this.Name = "Form_AddWorker";
            this.Text = "Form_AddWorker";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label hire_date_label;
        private System.Windows.Forms.Label phone_number_label;
        private System.Windows.Forms.Label birth_date_label;
        private System.Windows.Forms.Label w_name_label;
        private System.Windows.Forms.Label id_label;
        private System.Windows.Forms.TextBox hire_date_textBox;
        private System.Windows.Forms.TextBox phone_number_textBox;
        private System.Windows.Forms.TextBox birth_date_textBox;
        private System.Windows.Forms.TextBox w_name_textBox;
        private System.Windows.Forms.TextBox id_textBox;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.Button add_button;
        private System.Windows.Forms.Label salary_label;
        private System.Windows.Forms.TextBox salary_textBox;
    }
}