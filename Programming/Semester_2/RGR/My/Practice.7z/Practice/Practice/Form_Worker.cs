﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practice
{
    public partial class Form_Worker : Form
    {
        public static string connectString = "Provider=Microsoft.ACE.OLEDB.16.0;Data Source=DatabaseP.accdb";
        private OleDbConnection dbConnection;
        public Form_Worker()
        {
            InitializeComponent();
            dbConnection = new OleDbConnection(connectString);
            dbConnection.Open();
        }

        private void Form_Worker_Load(object sender, EventArgs e)
        {
            this.workerTableAdapter.Fill(this.databasePDataSet.worker);
        }

        private void Form_Worker_FormClosing(object sender, FormClosingEventArgs e)
        {
            dbConnection.Close();
        }

        public void UpdateDataGridView()
        {
            this.workerTableAdapter.Fill(this.databasePDataSet.worker);
        }

        private void SaveChanges()
        {
            this.dataGridView1.EndEdit();
            this.workerBindingSource.EndEdit();
            this.workerTableAdapter.Update(this.databasePDataSet.worker);
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            SaveChanges();
            if (this.Owner != null)
                this.Owner.Show();
            this.Close();
        }

        private void add_worker_button_Click(object sender, EventArgs e)
        {
            Form_AddWorker faw = new Form_AddWorker();
            faw.Owner = this;
            faw.MainForm = this;
            faw.StartPosition = FormStartPosition.Manual;
            faw.Location = this.Location;
            faw.Show();
        }

        private void update_worker_button_Click(object sender, EventArgs e)
        {
            Form_UpdateWorker faw = new Form_UpdateWorker();
            faw.Owner = this;
            faw.MainForm = this;
            faw.StartPosition = FormStartPosition.Manual;
            faw.Location = this.Location;
            faw.Show();
        }

        private void by_ascending_button_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM worker ORDER BY 6 ASC";
            OleDbDataAdapter command = new OleDbDataAdapter(query, dbConnection);
            DataTable dt = new DataTable();
            command.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void by_descending_button_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM worker ORDER BY 6 DESC";
            OleDbDataAdapter command = new OleDbDataAdapter(query, dbConnection);
            DataTable dt = new DataTable();
            command.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void find_button_Click(object sender, EventArgs e)
        {
            try
            {
                string phone_number = find_textBox.Text;
                string query = "SELECT * FROM worker WHERE phone_number = @phone_number";
                OleDbCommand command = new OleDbCommand(query, dbConnection);
                command.Parameters.AddWithValue("@phone_number", phone_number);

                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(command);
                DataTable dt = new DataTable();
                dataAdapter.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void reset_button_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = databasePDataSet.worker;
        }

        private void delete_worker_button_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(delete_worker_textBox.Text);

                string query = "DELETE FROM worker WHERE [id] = @id";
                OleDbCommand command = new OleDbCommand(query, dbConnection);
                command.Parameters.AddWithValue("@id", id);
                command.ExecuteNonQuery();

                MessageBox.Show("Worker deleted successfully.");

                this.workerTableAdapter.Fill(this.databasePDataSet.worker);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
