﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practice
{
    public partial class Form_AddWorker : Form
    {
        public Form_Worker MainForm { get; set; }
        public static string connection = "Provider=Microsoft.ACE.OLEDB.16.0;Data Source=DatabaseP.accdb";
        private OleDbConnection dbConnection;
        public Form_AddWorker()
        {
            InitializeComponent();
            dbConnection = new OleDbConnection(connection);
            dbConnection.Open();
        }

        private void add_button_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(id_textBox.Text);
                string w_name = w_name_textBox.Text;
                DateTime birth_date = DateTime.Parse(birth_date_textBox.Text);
                string phone_number = phone_number_textBox.Text;
                DateTime hire_date = DateTime.Parse(hire_date_textBox.Text);
                int salary = Convert.ToInt32(salary_textBox.Text);

                string query = "INSERT INTO worker ([id], w_name, birth_date, phone_number, hire_date, salary) " +
                               "VALUES (@id, @w_name, @birth_date, @phone_number, @hire_date, @salary)";

                OleDbCommand command = new OleDbCommand(query, dbConnection);

                command.Parameters.AddWithValue("@id", id);
                command.Parameters.AddWithValue("@w_name", w_name);
                command.Parameters.AddWithValue("@birth_date", birth_date);
                command.Parameters.AddWithValue("@phone_number", phone_number);
                command.Parameters.AddWithValue("@hire_date", hire_date);
                command.Parameters.AddWithValue("@salary", salary);

                command.ExecuteNonQuery();

                MessageBox.Show("Worker added successfully!");

                MainForm.UpdateDataGridView();

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
