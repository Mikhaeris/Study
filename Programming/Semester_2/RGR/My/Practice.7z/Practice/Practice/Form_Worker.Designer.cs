﻿namespace Practice
{
    partial class Form_Worker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.exit_button = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phonenumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hiredateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salaryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.databasePDataSet = new Practice.DatabasePDataSet();
            this.workerTableAdapter = new Practice.DatabasePDataSetTableAdapters.workerTableAdapter();
            this.by_descending_button = new System.Windows.Forms.Button();
            this.by_ascending_button = new System.Windows.Forms.Button();
            this.sort_by_salary_label = new System.Windows.Forms.Label();
            this.reset_button = new System.Windows.Forms.Button();
            this.find_textBox = new System.Windows.Forms.TextBox();
            this.find_button = new System.Windows.Forms.Button();
            this.find_worker_by_phone_number_label = new System.Windows.Forms.Label();
            this.update_worker_button = new System.Windows.Forms.Button();
            this.delete_label = new System.Windows.Forms.Label();
            this.delete_worker_button = new System.Windows.Forms.Button();
            this.delete_worker_textBox = new System.Windows.Forms.TextBox();
            this.add_worker_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.workerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databasePDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // exit_button
            // 
            this.exit_button.Location = new System.Drawing.Point(675, 502);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(202, 69);
            this.exit_button.TabIndex = 2;
            this.exit_button.Text = "Выйти";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.wnameDataGridViewTextBoxColumn,
            this.birthdateDataGridViewTextBoxColumn,
            this.phonenumberDataGridViewTextBoxColumn,
            this.hiredateDataGridViewTextBoxColumn,
            this.salaryDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.workerBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(643, 559);
            this.dataGridView1.TabIndex = 3;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // wnameDataGridViewTextBoxColumn
            // 
            this.wnameDataGridViewTextBoxColumn.DataPropertyName = "w_name";
            this.wnameDataGridViewTextBoxColumn.HeaderText = "w_name";
            this.wnameDataGridViewTextBoxColumn.Name = "wnameDataGridViewTextBoxColumn";
            // 
            // birthdateDataGridViewTextBoxColumn
            // 
            this.birthdateDataGridViewTextBoxColumn.DataPropertyName = "birth_date";
            this.birthdateDataGridViewTextBoxColumn.HeaderText = "birth_date";
            this.birthdateDataGridViewTextBoxColumn.Name = "birthdateDataGridViewTextBoxColumn";
            // 
            // phonenumberDataGridViewTextBoxColumn
            // 
            this.phonenumberDataGridViewTextBoxColumn.DataPropertyName = "phone_number";
            this.phonenumberDataGridViewTextBoxColumn.HeaderText = "phone_number";
            this.phonenumberDataGridViewTextBoxColumn.Name = "phonenumberDataGridViewTextBoxColumn";
            // 
            // hiredateDataGridViewTextBoxColumn
            // 
            this.hiredateDataGridViewTextBoxColumn.DataPropertyName = "hire_date";
            this.hiredateDataGridViewTextBoxColumn.HeaderText = "hire_date";
            this.hiredateDataGridViewTextBoxColumn.Name = "hiredateDataGridViewTextBoxColumn";
            // 
            // salaryDataGridViewTextBoxColumn
            // 
            this.salaryDataGridViewTextBoxColumn.DataPropertyName = "salary";
            this.salaryDataGridViewTextBoxColumn.HeaderText = "salary";
            this.salaryDataGridViewTextBoxColumn.Name = "salaryDataGridViewTextBoxColumn";
            // 
            // workerBindingSource
            // 
            this.workerBindingSource.DataMember = "worker";
            this.workerBindingSource.DataSource = this.databasePDataSet;
            // 
            // databasePDataSet
            // 
            this.databasePDataSet.DataSetName = "DatabasePDataSet";
            this.databasePDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // workerTableAdapter
            // 
            this.workerTableAdapter.ClearBeforeFill = true;
            // 
            // by_descending_button
            // 
            this.by_descending_button.Location = new System.Drawing.Point(790, 224);
            this.by_descending_button.Name = "by_descending_button";
            this.by_descending_button.Size = new System.Drawing.Size(95, 42);
            this.by_descending_button.TabIndex = 26;
            this.by_descending_button.Text = "По убыванию";
            this.by_descending_button.UseVisualStyleBackColor = true;
            this.by_descending_button.Click += new System.EventHandler(this.by_descending_button_Click);
            // 
            // by_ascending_button
            // 
            this.by_ascending_button.Location = new System.Drawing.Point(675, 224);
            this.by_ascending_button.Name = "by_ascending_button";
            this.by_ascending_button.Size = new System.Drawing.Size(109, 42);
            this.by_ascending_button.TabIndex = 25;
            this.by_ascending_button.Text = " По возрастанию";
            this.by_ascending_button.UseVisualStyleBackColor = true;
            this.by_ascending_button.Click += new System.EventHandler(this.by_ascending_button_Click);
            // 
            // sort_by_salary_label
            // 
            this.sort_by_salary_label.AutoSize = true;
            this.sort_by_salary_label.Location = new System.Drawing.Point(690, 195);
            this.sort_by_salary_label.Name = "sort_by_salary_label";
            this.sort_by_salary_label.Size = new System.Drawing.Size(117, 13);
            this.sort_by_salary_label.TabIndex = 24;
            this.sort_by_salary_label.Text = "Сортировать по salary";
            // 
            // reset_button
            // 
            this.reset_button.Location = new System.Drawing.Point(743, 335);
            this.reset_button.Name = "reset_button";
            this.reset_button.Size = new System.Drawing.Size(64, 42);
            this.reset_button.TabIndex = 23;
            this.reset_button.Text = "Сбросить";
            this.reset_button.UseVisualStyleBackColor = true;
            this.reset_button.Click += new System.EventHandler(this.reset_button_Click);
            // 
            // find_textBox
            // 
            this.find_textBox.Location = new System.Drawing.Point(673, 309);
            this.find_textBox.Name = "find_textBox";
            this.find_textBox.Size = new System.Drawing.Size(134, 20);
            this.find_textBox.TabIndex = 22;
            // 
            // find_button
            // 
            this.find_button.Location = new System.Drawing.Point(673, 335);
            this.find_button.Name = "find_button";
            this.find_button.Size = new System.Drawing.Size(64, 42);
            this.find_button.TabIndex = 21;
            this.find_button.Text = "Найти";
            this.find_button.UseVisualStyleBackColor = true;
            this.find_button.Click += new System.EventHandler(this.find_button_Click);
            // 
            // find_worker_by_phone_number_label
            // 
            this.find_worker_by_phone_number_label.AutoSize = true;
            this.find_worker_by_phone_number_label.Location = new System.Drawing.Point(670, 282);
            this.find_worker_by_phone_number_label.Name = "find_worker_by_phone_number_label";
            this.find_worker_by_phone_number_label.Size = new System.Drawing.Size(183, 13);
            this.find_worker_by_phone_number_label.TabIndex = 20;
            this.find_worker_by_phone_number_label.Text = "Найти работника по phone_number";
            // 
            // update_worker_button
            // 
            this.update_worker_button.Location = new System.Drawing.Point(675, 103);
            this.update_worker_button.Name = "update_worker_button";
            this.update_worker_button.Size = new System.Drawing.Size(202, 73);
            this.update_worker_button.TabIndex = 19;
            this.update_worker_button.Text = "Обновить сотрудника";
            this.update_worker_button.UseVisualStyleBackColor = true;
            this.update_worker_button.Click += new System.EventHandler(this.update_worker_button_Click);
            // 
            // delete_label
            // 
            this.delete_label.AutoSize = true;
            this.delete_label.Location = new System.Drawing.Point(672, 392);
            this.delete_label.Name = "delete_label";
            this.delete_label.Size = new System.Drawing.Size(131, 13);
            this.delete_label.TabIndex = 18;
            this.delete_label.Text = "Введите id для удаления";
            // 
            // delete_worker_button
            // 
            this.delete_worker_button.Location = new System.Drawing.Point(673, 445);
            this.delete_worker_button.Name = "delete_worker_button";
            this.delete_worker_button.Size = new System.Drawing.Size(129, 42);
            this.delete_worker_button.TabIndex = 17;
            this.delete_worker_button.Text = "Удалить сотрудника";
            this.delete_worker_button.UseVisualStyleBackColor = true;
            this.delete_worker_button.Click += new System.EventHandler(this.delete_worker_button_Click);
            // 
            // delete_worker_textBox
            // 
            this.delete_worker_textBox.Location = new System.Drawing.Point(673, 418);
            this.delete_worker_textBox.Name = "delete_worker_textBox";
            this.delete_worker_textBox.Size = new System.Drawing.Size(129, 20);
            this.delete_worker_textBox.TabIndex = 16;
            // 
            // add_worker_button
            // 
            this.add_worker_button.Location = new System.Drawing.Point(675, 12);
            this.add_worker_button.Name = "add_worker_button";
            this.add_worker_button.Size = new System.Drawing.Size(202, 73);
            this.add_worker_button.TabIndex = 15;
            this.add_worker_button.Text = "Добавить сотрудника";
            this.add_worker_button.UseVisualStyleBackColor = true;
            this.add_worker_button.Click += new System.EventHandler(this.add_worker_button_Click);
            // 
            // Form_Worker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(890, 589);
            this.Controls.Add(this.by_descending_button);
            this.Controls.Add(this.by_ascending_button);
            this.Controls.Add(this.sort_by_salary_label);
            this.Controls.Add(this.reset_button);
            this.Controls.Add(this.find_textBox);
            this.Controls.Add(this.find_button);
            this.Controls.Add(this.find_worker_by_phone_number_label);
            this.Controls.Add(this.update_worker_button);
            this.Controls.Add(this.delete_label);
            this.Controls.Add(this.delete_worker_button);
            this.Controls.Add(this.delete_worker_textBox);
            this.Controls.Add(this.add_worker_button);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.exit_button);
            this.Name = "Form_Worker";
            this.Text = "База работников";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Worker_FormClosing);
            this.Load += new System.EventHandler(this.Form_Worker_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.workerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databasePDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DatabasePDataSet databasePDataSet;
        private System.Windows.Forms.BindingSource workerBindingSource;
        private DatabasePDataSetTableAdapters.workerTableAdapter workerTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phonenumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hiredateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn salaryDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button by_descending_button;
        private System.Windows.Forms.Button by_ascending_button;
        private System.Windows.Forms.Label sort_by_salary_label;
        private System.Windows.Forms.Button reset_button;
        private System.Windows.Forms.TextBox find_textBox;
        private System.Windows.Forms.Button find_button;
        private System.Windows.Forms.Label find_worker_by_phone_number_label;
        private System.Windows.Forms.Button update_worker_button;
        private System.Windows.Forms.Label delete_label;
        private System.Windows.Forms.Button delete_worker_button;
        private System.Windows.Forms.TextBox delete_worker_textBox;
        private System.Windows.Forms.Button add_worker_button;
    }
}