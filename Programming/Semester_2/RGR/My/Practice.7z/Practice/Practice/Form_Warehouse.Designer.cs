﻿namespace Practice
{
    partial class Form_Warehouse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.exit_button = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.producttypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.placescountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workeridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.warehouseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.databasePDataSet1 = new Practice.DatabasePDataSet1();
            this.warehouseTableAdapter = new Practice.DatabasePDataSet1TableAdapters.warehouseTableAdapter();
            this.add_warehouse_button = new System.Windows.Forms.Button();
            this.delete_warehouse_textBox = new System.Windows.Forms.TextBox();
            this.delete_warehouse_button = new System.Windows.Forms.Button();
            this.delete_label = new System.Windows.Forms.Label();
            this.update_warehouse_button = new System.Windows.Forms.Button();
            this.find_worker_by_id_label = new System.Windows.Forms.Label();
            this.find_button = new System.Windows.Forms.Button();
            this.find_textBox = new System.Windows.Forms.TextBox();
            this.reset_button = new System.Windows.Forms.Button();
            this.by_descending_button = new System.Windows.Forms.Button();
            this.by_ascending_button = new System.Windows.Forms.Button();
            this.sort_by_places_count_label = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.warehouseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databasePDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // exit_button
            // 
            this.exit_button.Location = new System.Drawing.Point(571, 517);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(202, 69);
            this.exit_button.TabIndex = 1;
            this.exit_button.Text = "Выйти";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.producttypeDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.placescountDataGridViewTextBoxColumn,
            this.workeridDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.warehouseBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(13, 13);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(543, 573);
            this.dataGridView1.TabIndex = 2;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // producttypeDataGridViewTextBoxColumn
            // 
            this.producttypeDataGridViewTextBoxColumn.DataPropertyName = "product_type";
            this.producttypeDataGridViewTextBoxColumn.HeaderText = "product_type";
            this.producttypeDataGridViewTextBoxColumn.Name = "producttypeDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // placescountDataGridViewTextBoxColumn
            // 
            this.placescountDataGridViewTextBoxColumn.DataPropertyName = "places_count";
            this.placescountDataGridViewTextBoxColumn.HeaderText = "places_count";
            this.placescountDataGridViewTextBoxColumn.Name = "placescountDataGridViewTextBoxColumn";
            // 
            // workeridDataGridViewTextBoxColumn
            // 
            this.workeridDataGridViewTextBoxColumn.DataPropertyName = "worker_id";
            this.workeridDataGridViewTextBoxColumn.HeaderText = "worker_id";
            this.workeridDataGridViewTextBoxColumn.Name = "workeridDataGridViewTextBoxColumn";
            // 
            // warehouseBindingSource
            // 
            this.warehouseBindingSource.DataMember = "warehouse";
            this.warehouseBindingSource.DataSource = this.databasePDataSet1;
            // 
            // databasePDataSet1
            // 
            this.databasePDataSet1.DataSetName = "DatabasePDataSet1";
            this.databasePDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // warehouseTableAdapter
            // 
            this.warehouseTableAdapter.ClearBeforeFill = true;
            // 
            // add_warehouse_button
            // 
            this.add_warehouse_button.Location = new System.Drawing.Point(571, 22);
            this.add_warehouse_button.Name = "add_warehouse_button";
            this.add_warehouse_button.Size = new System.Drawing.Size(202, 73);
            this.add_warehouse_button.TabIndex = 3;
            this.add_warehouse_button.Text = "Добавить склад";
            this.add_warehouse_button.UseVisualStyleBackColor = true;
            this.add_warehouse_button.Click += new System.EventHandler(this.add_warehouse_button_Click);
            // 
            // delete_warehouse_textBox
            // 
            this.delete_warehouse_textBox.Location = new System.Drawing.Point(569, 428);
            this.delete_warehouse_textBox.Name = "delete_warehouse_textBox";
            this.delete_warehouse_textBox.Size = new System.Drawing.Size(129, 20);
            this.delete_warehouse_textBox.TabIndex = 4;
            // 
            // delete_warehouse_button
            // 
            this.delete_warehouse_button.Location = new System.Drawing.Point(569, 455);
            this.delete_warehouse_button.Name = "delete_warehouse_button";
            this.delete_warehouse_button.Size = new System.Drawing.Size(129, 42);
            this.delete_warehouse_button.TabIndex = 5;
            this.delete_warehouse_button.Text = "Удалить склад";
            this.delete_warehouse_button.UseVisualStyleBackColor = true;
            this.delete_warehouse_button.Click += new System.EventHandler(this.delete_warehouse_button_Click);
            // 
            // delete_label
            // 
            this.delete_label.AutoSize = true;
            this.delete_label.Location = new System.Drawing.Point(568, 402);
            this.delete_label.Name = "delete_label";
            this.delete_label.Size = new System.Drawing.Size(170, 13);
            this.delete_label.TabIndex = 6;
            this.delete_label.Text = "Введите id для удаления склада";
            // 
            // update_warehouse_button
            // 
            this.update_warehouse_button.Location = new System.Drawing.Point(571, 113);
            this.update_warehouse_button.Name = "update_warehouse_button";
            this.update_warehouse_button.Size = new System.Drawing.Size(202, 73);
            this.update_warehouse_button.TabIndex = 7;
            this.update_warehouse_button.Text = "Обновить склад";
            this.update_warehouse_button.UseVisualStyleBackColor = true;
            this.update_warehouse_button.Click += new System.EventHandler(this.update_warehouse_button_Click);
            // 
            // find_worker_by_id_label
            // 
            this.find_worker_by_id_label.AutoSize = true;
            this.find_worker_by_id_label.Location = new System.Drawing.Point(566, 292);
            this.find_worker_by_id_label.Name = "find_worker_by_id_label";
            this.find_worker_by_id_label.Size = new System.Drawing.Size(97, 13);
            this.find_worker_by_id_label.TabIndex = 8;
            this.find_worker_by_id_label.Text = "Найти склад по id";
            // 
            // find_button
            // 
            this.find_button.Location = new System.Drawing.Point(569, 345);
            this.find_button.Name = "find_button";
            this.find_button.Size = new System.Drawing.Size(64, 42);
            this.find_button.TabIndex = 9;
            this.find_button.Text = "Найти";
            this.find_button.UseVisualStyleBackColor = true;
            this.find_button.Click += new System.EventHandler(this.find_button_Click);
            // 
            // find_textBox
            // 
            this.find_textBox.Location = new System.Drawing.Point(569, 319);
            this.find_textBox.Name = "find_textBox";
            this.find_textBox.Size = new System.Drawing.Size(134, 20);
            this.find_textBox.TabIndex = 10;
            // 
            // reset_button
            // 
            this.reset_button.Location = new System.Drawing.Point(639, 345);
            this.reset_button.Name = "reset_button";
            this.reset_button.Size = new System.Drawing.Size(64, 42);
            this.reset_button.TabIndex = 11;
            this.reset_button.Text = "Сбросить";
            this.reset_button.UseVisualStyleBackColor = true;
            this.reset_button.Click += new System.EventHandler(this.reset_button_Click);
            // 
            // by_descending_button
            // 
            this.by_descending_button.Location = new System.Drawing.Point(678, 234);
            this.by_descending_button.Name = "by_descending_button";
            this.by_descending_button.Size = new System.Drawing.Size(95, 42);
            this.by_descending_button.TabIndex = 14;
            this.by_descending_button.Text = "По убыванию";
            this.by_descending_button.UseVisualStyleBackColor = true;
            this.by_descending_button.Click += new System.EventHandler(this.by_descending_button_Click);
            // 
            // by_ascending_button
            // 
            this.by_ascending_button.Location = new System.Drawing.Point(571, 234);
            this.by_ascending_button.Name = "by_ascending_button";
            this.by_ascending_button.Size = new System.Drawing.Size(101, 42);
            this.by_ascending_button.TabIndex = 13;
            this.by_ascending_button.Text = "По возрастанию";
            this.by_ascending_button.UseVisualStyleBackColor = true;
            this.by_ascending_button.Click += new System.EventHandler(this.by_ascending_button_Click);
            // 
            // sort_by_places_count_label
            // 
            this.sort_by_places_count_label.AutoSize = true;
            this.sort_by_places_count_label.Location = new System.Drawing.Point(568, 205);
            this.sort_by_places_count_label.Name = "sort_by_places_count_label";
            this.sort_by_places_count_label.Size = new System.Drawing.Size(149, 13);
            this.sort_by_places_count_label.TabIndex = 12;
            this.sort_by_places_count_label.Text = "Сортировка по places_count";
            // 
            // Form_Warehouse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 596);
            this.Controls.Add(this.by_descending_button);
            this.Controls.Add(this.by_ascending_button);
            this.Controls.Add(this.sort_by_places_count_label);
            this.Controls.Add(this.reset_button);
            this.Controls.Add(this.find_textBox);
            this.Controls.Add(this.find_button);
            this.Controls.Add(this.find_worker_by_id_label);
            this.Controls.Add(this.update_warehouse_button);
            this.Controls.Add(this.delete_label);
            this.Controls.Add(this.delete_warehouse_button);
            this.Controls.Add(this.delete_warehouse_textBox);
            this.Controls.Add(this.add_warehouse_button);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.exit_button);
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.Name = "Form_Warehouse";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "База складов";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Warehouse_FormClosing);
            this.Load += new System.EventHandler(this.Form_Warehouse_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.warehouseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databasePDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DatabasePDataSet1 databasePDataSet1;
        private System.Windows.Forms.BindingSource warehouseBindingSource;
        private DatabasePDataSet1TableAdapters.warehouseTableAdapter warehouseTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn producttypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn placescountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn workeridDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button add_warehouse_button;
        private System.Windows.Forms.TextBox delete_warehouse_textBox;
        private System.Windows.Forms.Button delete_warehouse_button;
        private System.Windows.Forms.Label delete_label;
        private System.Windows.Forms.Button update_warehouse_button;
        private System.Windows.Forms.Label find_worker_by_id_label;
        private System.Windows.Forms.Button find_button;
        private System.Windows.Forms.TextBox find_textBox;
        private System.Windows.Forms.Button reset_button;
        private System.Windows.Forms.Button by_descending_button;
        private System.Windows.Forms.Button by_ascending_button;
        private System.Windows.Forms.Label sort_by_places_count_label;
    }
}